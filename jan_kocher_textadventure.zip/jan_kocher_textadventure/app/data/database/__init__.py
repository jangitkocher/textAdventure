from .manager import DataBaseManager, ObjectName
