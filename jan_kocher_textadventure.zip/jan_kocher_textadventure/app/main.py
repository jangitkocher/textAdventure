from game_controller import GameController

if __name__ == '__main__':
    game_controller = GameController()
    game_controller.start_game()




